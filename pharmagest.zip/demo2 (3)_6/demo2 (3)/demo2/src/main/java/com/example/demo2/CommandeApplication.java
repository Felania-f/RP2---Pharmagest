package com.example.demo2;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import java.io.IOException;

public class CommandeApplication extends Application {

    private Stage primaryStage; // Le stage principal de l'application
    private BorderPane rootLayout; // Le layout racine de l'application

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.primaryStage.setTitle("Commande Application"); // Définit le titre de l'application

        initRootLayout(); // Initialise le layout racine
        showCommandeView(); // Affiche la vue de la commande
    }

    // Initialise le layout racine
    public void initRootLayout() {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(CommandeApplication.class.getResource("RootLayout.fxml"));
            rootLayout = (BorderPane) loader.load();

            // Définit la largeur et la hauteur souhaitées pour le layout racine
            rootLayout.setPrefWidth(1435);
            rootLayout.setPrefHeight(800);

            Scene scene = new Scene(rootLayout, 1435, 800); // Crée une nouvelle scène avec le layout racine
            // Définit la scène dans le stage principal
            primaryStage.setScene(scene);
            // Affiche le stage(fenetre) principal
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Affiche la vue de la commande
    public void showCommandeView() {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(CommandeApplication.class.getResource("Commande.fxml"));
            AnchorPane commandeView = (AnchorPane) loader.load();
            rootLayout.setCenter(commandeView);
            // Définit la vue de la commande au centre du layout racine
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    // Méthode principale qui lance l'application
    public static void main(String[] args) {
        launch(args);
    }
}
