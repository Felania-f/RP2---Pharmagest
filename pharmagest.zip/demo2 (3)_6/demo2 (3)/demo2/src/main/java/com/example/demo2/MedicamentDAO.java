package com.example.demo2;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;

//Ce code Java définit une classe MedicamentDAO pour interagir avec une base de données de médicaments.
// Il offre des méthodes pour rechercher, mettre à jour, insérer et supprimer des médicaments dans la base de données.
// La classe utilise des objets PreparedStatement pour exécuter des requêtes SQL et récupérer les résultats.

public class MedicamentDAO {

    // Méthode pour rechercher un médicament par son identifiant
    public static Medicament searchMedicament(String medicamentId) throws SQLException, ClassNotFoundException {
        // Crée une requête SQL pour sélectionner un médicament par son identifiant
        String selectStmt = "SELECT * FROM medicament WHERE id=" + medicamentId;

        try {
            // Exécute la requête et récupère le résultat
            ResultSet rsMedicament = DBUtil.dbExecuteQuery(selectStmt);
            // Transforme le résultat en objet Medicament
            Medicament medicament = getMedicamentFromResultSet(rsMedicament);
            return medicament;
        } catch (SQLException e) {
            System.out.println("While searching a medicament with " + medicamentId + " id, an error occurred: " + e);
            throw e;
        }
    }

    // Méthode privée pour extraire un médicament d'un ResultSet
    private static Medicament getMedicamentFromResultSet(ResultSet rs) throws SQLException {
        Medicament medicament = null;
        // Si le ResultSet contient au moins une ligne, crée un objet Medicament avec les données de la première ligne
        if (rs.next()) {
            medicament = new Medicament();
            medicament.setidmedicament(rs.getInt("id"));
            medicament.setnommedicament(rs.getString("nom"));
            medicament.setfournisseurmedicament(rs.getString("fournisseur"));
            medicament.setfamillemedicament(rs.getString("famille"));
            medicament.setformemedicament(rs.getString("forme"));
            medicament.setquantitemincommandemedicament(rs.getInt("quantitemincommande"));
            medicament.setquantitemaxstockmedicament(rs.getInt("quantitemaxstock"));
            medicament.setquantiteenstockmedicament(rs.getInt("quantiteenstock"));
            medicament.setordonnancemedicament(rs.getBoolean("ordonnance"));
            medicament.setprixmedicament(rs.getDouble("prixvente"));
            medicament.setprixunitaireachatmedicament(rs.getDouble("prixunitaireachat"));
            medicament.setprixventemedicament(rs.getDouble("prixvente"));
            medicament.setdatemiseajourmedicament(rs.getString("datemiseajour"));
        }
        return medicament;
    }


    // Méthode privée pour extraire une liste de médicaments d'un ResultSet
    private static ObservableList<Medicament> getMedicamentList(ResultSet rs) throws SQLException, ClassNotFoundException {
        ObservableList<Medicament> medicamentList = FXCollections.observableArrayList();

        // Parcourt le ResultSet et crée un objet Medicament pour chaque ligne
        while (rs.next()) {
            Medicament medicament = new Medicament();
            medicament.setidmedicament(rs.getInt("id"));
            medicament.setnommedicament(rs.getString("nom"));
            medicament.setfournisseurmedicament(rs.getString("fournisseur"));
            medicament.setfamillemedicament(rs.getString("famille"));
            medicament.setformemedicament(rs.getString("forme"));
            medicament.setquantitemincommandemedicament(rs.getInt("quantitemincommande"));
            medicament.setquantitemaxstockmedicament(rs.getInt("quantitemaxstock"));
            medicament.setquantiteenstockmedicament(rs.getInt("quantiteenstock"));
            medicament.setordonnancemedicament(rs.getBoolean("ordonnance"));
            medicament.setprixmedicament(rs.getDouble("prixvente"));
            medicament.setprixunitaireachatmedicament(rs.getDouble("prixunitaireachat"));
            medicament.setprixventemedicament(rs.getDouble("prixvente"));
            medicament.setdatemiseajourmedicament(rs.getString("datemiseajour"));

            //Ajouter l'objet Medicament créé à la liste
            medicamentList.add(medicament);
        }
        return medicamentList;
    }

    // Méthodes pour mettre à jour les différentes propriétés d'un médicament
    public static void updateMedicamentNom(int medicamentId, String newValue) throws SQLException, ClassNotFoundException {
        // SQL pour mettre à jour le nom du médicament
        String updateStmt = "UPDATE medicament SET nom = ? WHERE id = ?";
        try {
            try (PreparedStatement preparedStatement = DBUtil.dbConnect().prepareStatement(updateStmt)) {
                preparedStatement.setString(1, newValue);
                preparedStatement.setInt(2, medicamentId);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            System.out.print("Error occurred while UPDATE Operation: " + e);
            throw e;
        }
    }

    // Méthode pour vérifier si un fournisseur exists déjà dans la base de données
    public static void updateMedicamentFournisseur(int medicamentId, String newValue) throws SQLException, ClassNotFoundException {
        String updateStmt = "UPDATE medicament SET fournisseur = ? WHERE id = ?";
        try {
            try (PreparedStatement preparedStatement = DBUtil.dbConnect().prepareStatement(updateStmt)) {
                preparedStatement.setString(1, newValue);
                preparedStatement.setInt(2, medicamentId);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            System.out.print("Error occurred while UPDATE Operation: " + e);
            throw e;
        }
    }

    // Méthodes pour mettre à jour les différentes propriétés d'un médicament
    public static void updateMedicamentFamille(int medicamentId, String newValue) throws SQLException, ClassNotFoundException {
        // SQL pour mettre à jour le nom du médicament
        String updateStmt = "UPDATE medicament SET famille = ? WHERE id = ?";
        try {
            try (PreparedStatement preparedStatement = DBUtil.dbConnect().prepareStatement(updateStmt)) {
                preparedStatement.setString(1, newValue);
                preparedStatement.setInt(2, medicamentId);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            System.out.print("Error occurred while UPDATE Operation: " + e);
            throw e;
        }
    }

    public static void updateMedicamentForme(int medicamentId, String newValue) throws SQLException, ClassNotFoundException {
        String updateStmt = "UPDATE medicament SET forme = ? WHERE id = ?";
        try {
            try (PreparedStatement preparedStatement = DBUtil.dbConnect().prepareStatement(updateStmt)) {
                preparedStatement.setString(1, newValue);
                preparedStatement.setInt(2, medicamentId);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            System.out.print("Error occurred while UPDATE Operation: " + e);
            throw e;
        }
    }

    public static void updateMedicamentQuantiteMinCommande(int medicamentId, int newValue) throws SQLException, ClassNotFoundException {
        String updateStmt = "UPDATE medicament SET quantitemincommande = ? WHERE id = ?";
        try {
            try (PreparedStatement preparedStatement = DBUtil.dbConnect().prepareStatement(updateStmt)) {
                preparedStatement.setInt(1, newValue);
                preparedStatement.setInt(2, medicamentId);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            System.out.print("Error occurred while UPDATE Operation: " + e);
            throw e;
        }
    }


    public static void updateMedicamentQuantiteMaxStock(int medicamentId, int newValue) throws SQLException, ClassNotFoundException {
        String updateStmt = "UPDATE medicament SET quantitemaxstock = ? WHERE id = ?";
        try {
            try (PreparedStatement preparedStatement = DBUtil.dbConnect().prepareStatement(updateStmt)) {
                preparedStatement.setInt(1, newValue);
                preparedStatement.setInt(2, medicamentId);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            System.out.print("Error occurred while UPDATE Operation: " + e);
            throw e;
        }
    }

    public static void updateMedicamentQuantiteEnStock(int medicamentId, int newStock) throws SQLException, ClassNotFoundException {
        Connection connection = DBUtil.dbConnect();
        String query = "UPDATE medicament SET quantiteenstock = ? WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, newStock);
            statement.setInt(2, medicamentId);
            statement.executeUpdate();
        } catch (SQLException e) {
            System.out.print("Error occurred while UPDATE Operation: " + e);
            throw e;
        } finally {
            connection.close();
        }
    }

    public static void updateMedicamentOrdonnance(int medicamentId, boolean newOrdonnance) throws SQLException, ClassNotFoundException {
        String updateStmt = "UPDATE medicament SET ordonnance = ? WHERE id = ?";
        try (Connection connection = DBUtil.dbConnect();
             PreparedStatement preparedStatement = connection.prepareStatement(updateStmt)) {
            preparedStatement.setBoolean(1, newOrdonnance);
            preparedStatement.setInt(2, medicamentId);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            System.out.print("Error occurred while UPDATE Operation: " + e);
            throw e;
        }
    }

    // Méthode pour insérer un nouveau médicament dans la base de données
    public static void insertMedicament(String nommedicament, String fournisseurmedicament, String famillemedicament, String formemedicament, Integer quantitemincommande, Integer quantitemaxstock, Integer quantiteenstock, Boolean ordonnance) throws SQLException, ClassNotFoundException {

        String insertStmt = "INSERT INTO medicament " +
                "(nom, fournisseur, famille, forme, quantitemincommande, quantitemaxstock, quantiteenstock, ordonnance) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try {


            try (PreparedStatement insertStatement = DBUtil.dbConnect().prepareStatement(insertStmt)) {
                insertStatement.setString(1, nommedicament);
                insertStatement.setString(2, fournisseurmedicament);
                insertStatement.setString(3, famillemedicament);
                insertStatement.setString(4, formemedicament);
                insertStatement.setInt(5, quantitemincommande);
                insertStatement.setInt(6, quantitemaxstock);
                insertStatement.setInt(7, quantiteenstock);
                insertStatement.setBoolean(8, ordonnance);

                int rowsAffected = insertStatement.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Medicament inserted successfully.");
                } else {
                    System.out.println("Failed to insert medicament.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error occurred while inserting medicament: " + e);
            throw e;
        }
    }

    public static boolean fournisseurExists(String fournisseurmedicament) throws SQLException, ClassNotFoundException {
        // SQL query to check if the fournisseur exists
        String query = "SELECT COUNT(*) FROM fournisseurs WHERE nomfournisseur = ?";

        // Try-with-resources to automatically close resources
        try (PreparedStatement statement = DBUtil.dbConnect().prepareStatement(query)) {
            statement.setString(1, fournisseurmedicament);

            // Execute the query
            try (ResultSet resultSet = statement.executeQuery()) {
                // If the result set has at least one row, the fournisseur exists
                if (resultSet.next()) {
                    int count = resultSet.getInt(1);
                    return count > 0;
                }
            }
        }
        return false;
    }

    // Méthode pour supprimer un médicament avec un identifiant spécifique
    public static void deletemedicamentwithid(String medicamentId) throws SQLException, ClassNotFoundException {
        // Requête SQL de suppression d'un médicament avec un identifiant spécifique
        String deleteStmt =
                "DELETE FROM medicament\n" +
                        "WHERE id = '" + medicamentId + "'";

        try {
            // Exécute la requête de suppression en utilisant la classe DBUtil
            DBUtil.dbExecuteUpdate(deleteStmt);
        } catch (SQLException e) {
            // En cas d'erreur, affiche un message d'erreur et relance l'exception
            System.out.print("Error occurred while DELETE Operation: " + e);
            throw e;
        }
    }

    // Méthode pour rechercher tous les médicaments dans la base de données
    public static ObservableList<Medicament> searchAllMedicaments() throws SQLException, ClassNotFoundException {
        // Requête SQL pour sélectionner tous les médicaments
        String selectStmt = "SELECT * FROM medicament"; // Select all medicament
        try {
            // Exécute la requête et récupère le résultat
            ResultSet rsMedicaments = DBUtil.dbExecuteQuery(selectStmt);
            // Transforme le résultat en liste d'objets Medicament en utilisant la méthode getMedicamentList
            ObservableList<Medicament> medicamentList = getMedicamentList(rsMedicaments);
            return medicamentList;
        } catch (SQLException e) {
            // En cas d'erreur, affiche un message d'erreur, relance l'exception
            System.out.println("While searching for all medicaments, an error occurred: " + e);
            throw e;
        }
    }

    // Méthode pour mettre à jour la liste des prix d'un médicament
    public static void updateMedicamentListeDesPrix(Medicament medicament) throws SQLException, ClassNotFoundException {
        // Requête SQL de mise à jour des prix d'un médicament
        String updateStmt = "UPDATE medicament SET " +
                "prixunitaireachat = ?, " +
                "prixvente = ? " +
                "WHERE id = ?";

        try (Connection connection = DBUtil.dbConnect();
             PreparedStatement preparedStatement = connection.prepareStatement(updateStmt)) {

            // Définit les nouveaux prix du médicament dans la requête de mise à jour
            preparedStatement.setDouble(1, medicament.getprixunitaireachatmedicament());
            preparedStatement.setDouble(2, medicament.getprixventemedicament());
            preparedStatement.setInt(3, medicament.getidmedicament()); // Assuming you have a method getId() in Medicament class

            // Exécute la requête de mise à jour et récupère le nombre de lignes mises à jour
            int rowsUpdated = preparedStatement.executeUpdate();

            // Affiche un message en fonction du nombre de lignes mises à jour
            if (rowsUpdated > 0) {
                System.out.println("Update successful. Rows updated: " + rowsUpdated);
            } else {
                System.out.println("No rows updated. Please check if the specified ID exists: " + medicament.getidmedicament());
            }
        } catch (SQLException e) {
            // En cas d'erreur, affiche un message d'erreur, relance l'exception
            System.out.println("Error occurred while UPDATE Operation: " + e);
            throw e;
        }
    }
}
