package com.example.demo2;
import javafx.beans.property.*;
public class Réception {
    private final IntegerProperty idmedicament;
    private final StringProperty nom;
    private final StringProperty fournisseur;
    private final IntegerProperty quantitecommande;
    private final DoubleProperty prixunitaire;
    private final DoubleProperty total;

    public Réception(int idmedicament, String nom, String fournisseur, int quantitecommande, double prixunitaire) {
        this.idmedicament = new SimpleIntegerProperty(idmedicament);
        this.nom = new SimpleStringProperty(nom);
        this.fournisseur = new SimpleStringProperty(fournisseur);
        this.quantitecommande = new SimpleIntegerProperty(quantitecommande);
        this.prixunitaire = new SimpleDoubleProperty(prixunitaire);
        this.total = new SimpleDoubleProperty(prixunitaire*quantitecommande);
    }



    // Getter methods for properties
    public IntegerProperty idmedicamentProperty() {
        return idmedicament;
    }
    public StringProperty nomProperty() {
        return nom;
    }
    public StringProperty fournisseurProperty() {
        return fournisseur;
    }
    public IntegerProperty quantitecommandeProperty() {
        return quantitecommande;
    }
    public DoubleProperty prixunitaireProperty() {
        return prixunitaire;
    }
    public DoubleProperty totalProperty() {
        return new SimpleDoubleProperty(getPrixunitaire() * getQuantitecommande());
    }
    // Getter methods for properties
    public int getIdmedicament() {
        return idmedicament.get();
    }
    public String getNom() {
        return nom.get();
    }
    public String getFournisseur() {
        return fournisseur.get();
    }

    public int getQuantitecommande() {
        return quantitecommande.get();
    }
    public double getPrixunitaire() {
        return prixunitaire.get();
    }
}

