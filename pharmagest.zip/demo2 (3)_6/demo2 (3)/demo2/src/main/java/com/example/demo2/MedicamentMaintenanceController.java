package com.example.demo2;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import com.example.demo2.Fournisseur;
import com.example.demo2.FournisseurDAO;

import java.sql.Timestamp;
import java.sql.SQLException;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class MedicamentMaintenanceController {

    @FXML
    private TextField medicamentIdText;
    @FXML
    private TextArea resultArea;
    // Déclaration des autres champs de texte, des boutons, de la table et des colonnes de la table
    @FXML
    private TextField newmedicamentText;
    @FXML
    private TextField newnommedicamentText;
    @FXML
    private TextField newfournisseurmedicamentText;
    @FXML
    private TextField newfamillemedicamentText;
    @FXML
    private TextField newformemedicamentText;
    @FXML
    private TextField newquantitemincommandemedicamentText;
    @FXML
    private TextField newquantitemaxstockmedicamentText;
    @FXML
    private TextField newquantiteenstockmedicamentText;
    @FXML
    private ChoiceBox<String> newordonnancemedicamentText;
    @FXML
    private TableView medicamentTable;
    @FXML
    private TableColumn<Medicament, Integer> medicamentIdColumn;
    @FXML
    private TableColumn<Medicament, String> NomMedicamentColumn;
    @FXML
    private TableColumn<Medicament, String> FournisseurMedicamentColumn;
    @FXML
    private TableColumn<Medicament, String> FamilleMedicamentColumn;
    @FXML
    private TableColumn<Medicament, String> FormeMedicamentColumn;
    @FXML
    private TableColumn<Medicament, Integer> QuantiteMinCommandeMedicamentColumn;
    @FXML
    private TableColumn<Medicament, Integer> QuantiteMaxStockMedicamentColumn;
    @FXML
    private TableColumn<Medicament, Integer> QuantiteEnStockMedicamentColumn;
    @FXML
    private TableColumn<Medicament, Boolean> OrdonnanceMedicamentColumn;
    @FXML
    private ChoiceBox<String> updateMedicamentFieldChoiceBox;

    //Ce code Java définit un contrôleur pour une application JavaFX qui gère l'interface utilisateur pour la
    // maintenance des médicaments. Il utilise des annotations FXML pour lier les éléments de l'interface aux champs
    // et méthodes de la classe. Le contrôleur comprend des méthodes pour rechercher, insérer, mettre à jour et
    // supprimer des médicaments dans une base de données. Il utilise également le multithreading pour améliorer
    // les performances de l'application.

    // For MultiThreading
    private Executor exec;

    // Initialisation de controller class.
    // This method is automatically called after the fxml file has been loaded.
    @FXML
    private void initialize() {
        // Configuration des cellules de la table avec les propriétés des objets Medicament
        // Les lambdas (->) sont utilisées pour simplifier la définition des fonctions anonymes
        // Chaque cellData représente une cellule dans la table
        //medicamentIdColumn.setCellValueFactory(cellData -> cellData.getValue().idmedicamentProperty().asObject());
        // Déclaration des autres colonnes de la table

        // Création d'un Executor pour le multithreading
        exec = Executors.newCachedThreadPool(runnable -> {
            Thread t = new Thread(runnable);
            t.setDaemon(true);
            return t;
        });

        medicamentIdColumn.setCellValueFactory(cellData -> cellData.getValue().idmedicamentProperty().asObject());
        NomMedicamentColumn.setCellValueFactory(cellData -> cellData.getValue().nommedicamentProperty());
        FournisseurMedicamentColumn.setCellValueFactory(cellData -> cellData.getValue().fournisseurmedicamentProperty());
        FamilleMedicamentColumn.setCellValueFactory(cellData -> cellData.getValue().famillemedicamentProperty());
        FormeMedicamentColumn.setCellValueFactory(cellData -> cellData.getValue().formemedicamentProperty());
        QuantiteMinCommandeMedicamentColumn.setCellValueFactory(cellData -> cellData.getValue().quantitemincommandemedicamentProperty().asObject());
        QuantiteMaxStockMedicamentColumn.setCellValueFactory(cellData -> cellData.getValue().quantitemaxstockmedicamentProperty().asObject());
        QuantiteEnStockMedicamentColumn.setCellValueFactory(cellData -> cellData.getValue().quantiteenstockmedicamentProperty().asObject());
        OrdonnanceMedicamentColumn.setCellValueFactory(cellData -> cellData.getValue().ordonnancemedicamentProperty());

        // Récupération de tous les médicaments et affichage dans la table
        try {
            ObservableList<Medicament> allMedicaments = MedicamentDAO.searchAllMedicaments();
            populateMedicaments(allMedicaments);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            // Gestion de l'exception selon la logique de l'application
        }
        // Initialisation du choix par défaut dans la ChoiceBox
        updateMedicamentFieldChoiceBox.setValue("Nouveau Nom");
    }

    //Méthode pour rechercher un médicament
    @FXML
    private void searchMedicament(ActionEvent actionEvent) throws ClassNotFoundException, SQLException {
        try {
            // Récupération des informations du médicament
            Medicament medicament = MedicamentDAO.searchMedicament(medicamentIdText.getText());
            // Affichage des informations du médicament dans la table et dans la zone de texte
            populateAndShowMedicament(medicament);
        } catch (SQLException e) {
            e.printStackTrace();
            resultArea.setText("Error occurred while getting medicament information from DB.\n" + e);
            throw e;
        }
    }

    // Populate Utilisateur for TableView
    @FXML
    private void populateMedicament(Medicament medicament) throws ClassNotFoundException {
        // Declare and ObservableList for table view
        ObservableList<Medicament> medicamentData = FXCollections.observableArrayList();
        // Add utilisateur to the ObservableList
        medicamentData.add(medicament);
        // Set items to the utilisateurTable
        medicamentTable.setItems(medicamentData);
    }

    // Set Utilisateur information to Text Area
    @FXML
    private void setMedicamentInfoToTextArea(Medicament medicament) {
        resultArea.setText("Medicament: " + medicament.getnommedicament() + "\n" +
                "Fournisseur: " + medicament.getfournisseurmedicament() + "\n" +
                "Famille: " + medicament.getfamillemedicament());
    }

    // Populate Utilisateur for TableView and Display Utilisateur on TextArea
    @FXML
    private void populateAndShowMedicament(Medicament medicament) throws ClassNotFoundException {
        if (medicament != null) {
            populateMedicament(medicament);
            setMedicamentInfoToTextArea(medicament);
        } else {
            resultArea.setText("This medicament does not exist!\n");
        }
    }

    // Populate Utilisateurs for TableView
    @FXML
    private void populateMedicaments(ObservableList<Medicament> medicamentData) throws ClassNotFoundException {
        // Set items to the utilisateurTable
        medicamentTable.setItems(medicamentData);
    }

    // Update utilisateur's email with the email which is written on newEmailText field
    @FXML
    private void updateMedicamentField(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
        try {
            int medicamentId = Integer.parseInt(medicamentIdText.getText());
            String selectedField = updateMedicamentFieldChoiceBox.getValue();

            switch (selectedField) {

                case "Nouveau Nom":
                    String newName = newmedicamentText.getText();
                    MedicamentDAO.updateMedicamentNom(medicamentId, newName);
                    resultArea.setText("Nom has been updated for medicament id: " + medicamentId + "\n");
                    break;
                case "Nouveau Fournisseur":
                    String newFournisseur = newmedicamentText.getText();
                    MedicamentDAO.updateMedicamentFournisseur(medicamentId, newFournisseur);
                    resultArea.setText("Fournisseur has been updated for medicament id: " + medicamentId + "\n");
                    break;
                case "Nouvelle Famille":
                    String newFamille = newmedicamentText.getText();
                    MedicamentDAO.updateMedicamentFamille(medicamentId, newFamille);
                    resultArea.setText("Famille has been updated for medicament id: " + medicamentId + "\n");
                    break;
                case "Nouvelle Forme":
                    String newForme = newmedicamentText.getText();
                    MedicamentDAO.updateMedicamentForme(medicamentId, newForme);
                    resultArea.setText("Forme has been updated for medicament id: " + medicamentId + "\n");
                    break;
                case "Nouvelle quantitemincomm":
                    int newValue = Integer.parseInt(newmedicamentText.getText());
                    MedicamentDAO.updateMedicamentQuantiteMinCommande(medicamentId, newValue);
                    resultArea.setText("QuantiteMinComm has been updated for medicament id: " + medicamentId + "\n");
                    break;
                case "Nouvelle quantitemaxstock":
                    int newMaxStock = Integer.parseInt(newmedicamentText.getText());
                    MedicamentDAO.updateMedicamentQuantiteMaxStock(medicamentId, newMaxStock);
                    resultArea.setText("quantitemaxstock has been updated for medicament id: " + medicamentId + "\n");
                    break;
                case "Nouvelle quantiteenstock":
                    int newStock = Integer.parseInt(newmedicamentText.getText());
                    MedicamentDAO.updateMedicamentQuantiteEnStock(medicamentId, newStock);
                    resultArea.setText("quantiteenstock has been updated for medicament id: " + medicamentId + "\n");
                    break;
                case "Nouvelle Ordonnance":
                    boolean newOrdonnance = Boolean.parseBoolean(newmedicamentText.getText());
                    MedicamentDAO.updateMedicamentOrdonnance(medicamentId, newOrdonnance);
                    resultArea.setText("Ordonnance has been updated for medicament id: " + medicamentId + "\n");
                    break;
                default:
                    resultArea.setText("Invalid selection");
            }
        } catch (NumberFormatException e) {
            resultArea.setText("Error: Please enter a valid value for the selected field.\n" + e);
        } catch (SQLException e) {
            resultArea.setText("Problem occurred while updating field: " + e);
            throw e;
        }

        try {
            ObservableList<Medicament> allMedicaments = MedicamentDAO.searchAllMedicaments();
            populateMedicaments(allMedicaments);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            // Handle the exception according to your application's logic
        }
    }

    @FXML
    private Button supprimerButton; // Assuming you have a button named "supprimerButton" in your FXML file.


    @FXML
    private void supprimerMedicament(ActionEvent event) {
        // Check if the medicament ID text field is empty
        if (!medicamentIdText.getText().isEmpty()) {
            // If the text field is not empty, use the medicament ID from the text field for deletion
            String medicamentId = medicamentIdText.getText();

            try {
                // Delete the medicament with the provided ID
                MedicamentDAO.deletemedicamentwithid(medicamentId);
                resultArea.setText("Medicament deleted! Medicament id: " + medicamentId + "\n");

                // Refresh the TableView after deletion
                ObservableList<Medicament> allMedicaments = MedicamentDAO.searchAllMedicaments();
                populateMedicaments(allMedicaments);
            } catch (SQLException | ClassNotFoundException e) {
                resultArea.setText("Problem occurred while deleting medicament " + e);
                e.printStackTrace();
                // Handle the exception according to your application's logic
            }
        } else {
            // If the text field is empty, use the selected item from the TableView for deletion
            Medicament selectedMedicament = (Medicament) medicamentTable.getSelectionModel().getSelectedItem();

            if (selectedMedicament != null) {
                String medicamentId = String.valueOf(selectedMedicament.getidmedicament());

                try {
                    // Delete the medicament with the ID from the selected row
                    MedicamentDAO.deletemedicamentwithid(medicamentId);
                    resultArea.setText("Medicament deleted! Medicament id: " + medicamentId + "\n");

                    // Refresh the TableView after deletion
                    ObservableList<Medicament> allMedicaments = MedicamentDAO.searchAllMedicaments();
                    populateMedicaments(allMedicaments);
                } catch (SQLException | ClassNotFoundException e) {
                    resultArea.setText("Problem occurred while deleting medicament " + e);
                    e.printStackTrace();
                    // Handle the exception according to your application's logic
                }
            } else {
                // Inform the user to either select a medicament from the TableView or enter a medicament ID
                resultArea.setText("Please select a medicament from the table or enter a medicament ID.");
            }
        }
    }

    // Insert a utilisateur to the DB
    @FXML
    private void insertMedicament(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
        try {
            // Convert text inputs to appropriate data types
            String nommedicament = newnommedicamentText.getText();
            String fournisseurmedicament = newfournisseurmedicamentText.getText();
            String famillemedicament = newfamillemedicamentText.getText();
            String formemedicament = newformemedicamentText.getText();
            int quantitemincommandemedicament = Integer.parseInt(newquantitemincommandemedicamentText.getText());
            int quantitemaxstockmedicament = Integer.parseInt(newquantitemaxstockmedicamentText.getText());
            int quantiteenstockmedicament = Integer.parseInt(newquantiteenstockmedicamentText.getText());
            boolean ordonnancemedicament = Boolean.parseBoolean(newordonnancemedicamentText.getValue());

            // Check if the fournisseur exists
            boolean fournisseurExists = MedicamentDAO.fournisseurExists(fournisseurmedicament);
            if (!fournisseurExists) {
                String errorMessage = "The fournisseur '" + fournisseurmedicament + "' does not exist. Medicament not inserted.";
                resultArea.setText(errorMessage);
                return;
            }

            // Call the DAO method with the converted values
            MedicamentDAO.insertMedicament(nommedicament, fournisseurmedicament, famillemedicament, formemedicament, quantitemincommandemedicament, quantitemaxstockmedicament, quantiteenstockmedicament, ordonnancemedicament);

            // Display success message only if insertion was successful
            resultArea.setText("Medicament inserted!\n");

            // Clear input fields after successful insertion
            clearInputFields();
        } catch (NumberFormatException e) {
            resultArea.setText("Error: Please enter valid numeric values for quantity fields.\n" + e);
        } catch (SQLException e) {
            resultArea.setText("Problem occurred while inserting Medicament: " + e.getMessage());
            throw e;
        }
        try {
            ObservableList<Medicament> allMedicaments = MedicamentDAO.searchAllMedicaments();
            populateMedicaments(allMedicaments);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            // Handle the exception according to your application's logic
        }
    }

    // Helper method to clear input fields after successful insertion
    private void clearInputFields() {
        newnommedicamentText.clear();
        newfournisseurmedicamentText.clear();
        newfamillemedicamentText.clear();
        newformemedicamentText.clear();
        newquantitemincommandemedicamentText.clear();
        newquantitemaxstockmedicamentText.clear();
        newquantiteenstockmedicamentText.clear();
        newordonnancemedicamentText.setValue(null);
    }

    // Delete a utilisateur with a given utilisateur Id from DB
    @FXML
    private void deleteMedicament(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
        try {
            MedicamentDAO.deletemedicamentwithid(medicamentIdText.getText());
            resultArea.setText("Medicament deleted! Medicament id: " + medicamentIdText.getText() + "\n");
        } catch (SQLException e) {
            resultArea.setText("Problem occurred while deleting medicament " + e);
            throw e;
        }
        try {
            ObservableList<Medicament> allMedicaments = MedicamentDAO.searchAllMedicaments();
            populateMedicaments(allMedicaments);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            // Handle the exception according to your application's logic
        }
    }

    @FXML
    private void searchMedicaments(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
        try {
            // Get all medicaments information
            ObservableList<Medicament> medicamentData = MedicamentDAO.searchAllMedicaments();
            // Populate medicaments on TableView
            populateMedicaments(medicamentData);
        } catch (SQLException e) {
            System.out.println("Error occurred while getting medicaments information from DB.\n" + e);
            throw e;
        }
    }
}