package com.example.demo2;

import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import com.example.demo2.UtilisateurMaintenance;

public class RootLayoutController {

    /*//Reference to the main application
    private Main main;

    //Is called by the main application to give a reference back to itself.
    public void setMain (Main main) {
        this.main = main;
    }*/

    // Méthode pour gérer la sortie de l'application
    public void handleExit(ActionEvent actionEvent) {
        //Fermeture de l'application avec le code de sortie 0
        System.exit(0);
    }

    //Méthode pour afficher des informations d'aide
    public void handleHelp(ActionEvent actionEvent) {
        Alert alert = new Alert (Alert.AlertType.INFORMATION);
        //Configuration du titre de la boîte de dialogue
        alert.setTitle("Program Information");
        // Configuration de l'en-tête de la boîte de dialogue
        alert.setHeaderText("This is a sample JAVAFX application for SWTESTACADEMY!");
        // Configuration du contenu de la boîte de dialogue
        alert.setContentText("You can search, delete, update, insert a new employee with this program.");
        // Affichage de la boîte de dialogue
        alert.show();
    }
}
