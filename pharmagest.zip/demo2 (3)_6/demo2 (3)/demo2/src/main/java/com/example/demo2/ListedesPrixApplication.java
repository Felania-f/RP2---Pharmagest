package com.example.demo2;

import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class ListedesPrixApplication extends Application {

    // Méthode principale de l'application JavaFX
    public static void main(String[] args) {
        // Lance l'application JavaFX
        launch(args);
    }

    // Méthode appelée au démarrage de l'application
    @Override
    public void start(Stage primaryStage) {
        try {
            // Charge le fichier FXML de l'interface graphique
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ListeDesPrix.fxml"));
            Parent root = loader.load();

            // Crée une fenêtre avec le contenu chargé depuis le FXML
            Scene scene = new Scene(root);

            // Configure la fenêtre pour le stage principal de l'application
            primaryStage.setScene(scene);

            // Définit le titre de la fenêtre
            primaryStage.setTitle("Liste Des Prix App");

            //Maximise la fenêtre
            primaryStage.setMaximized(true);

            // Affiche le stage
            primaryStage.show();
        } catch (Exception e) {
            // Affiche les erreurs s'il y en a lors du chargement de l'interface graphique
            e.printStackTrace();
        }
    }
}