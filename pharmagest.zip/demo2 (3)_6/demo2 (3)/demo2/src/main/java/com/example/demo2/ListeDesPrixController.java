package com.example.demo2;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.commons.io.IOUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.concurrent.Executor;

import static com.example.demo2.DashboardController.username;

public class ListeDesPrixController {
    @FXML
    private TableView<Medicament> medicamentTable;
    @FXML
    private TableColumn<Medicament, String> datemiseajour;
    @FXML
    private TableColumn<Medicament, Double> prixunitaireachat;
    @FXML
    private TableColumn<Medicament, Double> prixvente;
    @FXML
    private TableColumn<Medicament, String> fournisseur;
    @FXML
    private TableColumn<Medicament, Integer> id;
    @FXML
    private TableColumn<Medicament, String> nom;
    @FXML
    private Label usernameLabel;
    @FXML
    private TextField BarDeRecherche;
    // Executor pour le multithreading
    private Executor exec;

    // Liste observable pour stocker tous les médicaments
    private ObservableList<Medicament> allMedicaments;

    // Initialisation de la classe du contrôleur.
    // Cette méthode est automatiquement appelée après le chargement du fichier fxml.
     @FXML
    private void initialize() {
         // Liaison des données aux colonnes de la TableView
        datemiseajour.setCellValueFactory(cellData -> cellData.getValue().datemiseajourmedicamentProperty());
        prixunitaireachat.setCellValueFactory(cellData -> cellData.getValue().prixunitaireachatmedicamentProperty().asObject());
        prixvente.setCellValueFactory(cellData -> cellData.getValue().prixventemedicamentProperty().asObject());
        fournisseur.setCellValueFactory(cellData -> cellData.getValue().fournisseurmedicamentProperty());
        id.setCellValueFactory(cellData -> cellData.getValue().idmedicamentProperty().asObject());
        nom.setCellValueFactory(cellData -> cellData.getValue().nommedicamentProperty());

        try {
            // Récupération de tous les médicaments depuis la base de données
            allMedicaments = MedicamentDAO.searchAllMedicaments();
            // Remplissage de la TableView avec les médicaments récupérés
            populateMedicaments(allMedicaments);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }

         // Configuration de la fonction de recherche
        setupSearchListener();
    }

    // Méthode pour remplir la TableView avec les médicaments
    private void populateMedicaments(ObservableList<Medicament> medicamentData) {
        // Set items to the medicamentTable
        medicamentTable.setItems(medicamentData);
    }

    // Méthode pour configurer la recherche en fonction du texte entré dans la barre de recherche
    private void setupSearchListener() {
        // Création d'une liste filtrée à partir de la liste des médicaments affichés
        FilteredList<Medicament> filteredList = new FilteredList<>(medicamentTable.getItems(), p -> true);

        // Ajout d'un écouteur sur le texte de la barre de recherche
        BarDeRecherche.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredList.setPredicate(medicament -> {
                if (newValue == null || newValue.isEmpty()) {
                    // If the search text is empty, show all items
                    return true;
                }

                // Conversion du texte de recherche en minuscules pour une recherche insensible à la casse
                String searchText = newValue.toLowerCase();

                // Vérification si les propriétés du médicament contiennent le texte de recherche
                return String.valueOf(medicament.getidmedicament()).toLowerCase().contains(searchText)
                        || String.valueOf(medicament.getprixunitaireachatmedicament()).toLowerCase().contains(searchText)
                        || String.valueOf(medicament.getprixventemedicament()).toLowerCase().contains(searchText)
                        || (medicament.getfournisseurmedicament() != null && medicament.getfournisseurmedicament().toLowerCase().contains(searchText))
                        || (medicament.getdatemiseajourmedicament() != null && medicament.getdatemiseajourmedicament().toLowerCase().contains(searchText))
                        || (medicament.getnommedicament() != null && medicament.getnommedicament().toLowerCase().contains(searchText));
            });
        });

        // Liaison de la liste filtrée à la TableView
        medicamentTable.setItems(filteredList);
    }

    // Méthode pour gérer l'importation de données à partir d'un fichier Excel
    @FXML
    private void handleImportExcelButton(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Excel Files", "*.xlsx", "*.xls"));
        File selectedFile = fileChooser.showOpenDialog(null);

        if (selectedFile != null) {
            // Traitement du fichier Excel sélectionné
            importDataFromExcel(selectedFile);

            // Récupération de tous les médicaments depuis la base de données après l'importation
            try {
                ObservableList<Medicament> allMedicaments = MedicamentDAO.searchAllMedicaments();
                // Remplissage de la TableView avec les médicaments mis à jour
                populateMedicaments(allMedicaments);
            } catch (SQLException | ClassNotFoundException e) {
                e.printStackTrace();
                // Handle appropriate exceptions
            }
        }
    }

    // Méthode pour importer les données à partir d'un fichier Excel
    private void importDataFromExcel(File excelFile) {
        FileInputStream fileInputStream = null;
        try {
            fileInputStream = new FileInputStream(excelFile);
            Workbook workbook = WorkbookFactory.create(fileInputStream);
            Sheet sheet = workbook.getSheetAt(0); // Assuming data is in the first sheet

            for (Row row : sheet) {
                // Supposant que les données sont séparées par des tabulations, découper la ligne en fonction des tabulations
                String[] rowData = new String[row.getLastCellNum()];
                for (int i = 0; i < row.getLastCellNum(); i++) {
                    Cell cell = row.getCell(i);
                    if (cell != null) {
                        if (cell.getCellType() == CellType.NUMERIC) {
                            rowData[i] = String.valueOf(cell.getNumericCellValue());
                        } else {
                            rowData[i] = cell.getStringCellValue();
                        }
                    } else {
                        rowData[i] = ""; // Or handle null values as needed
                    }
                }

                // Supposant que les données sont dans des colonnes spécifiques, mettre à jour les indices en conséquence
                int id = (int) Double.parseDouble(rowData[0]); // Assuming the ID is in the first column

                double prixunitaireachat = Double.parseDouble(rowData[2]);
                double prixvente = Double.parseDouble(rowData[3]);

                // Assuming other data follows the same pattern

                // Create a new instance of Medicament with the constructor that accepts the necessary parameters
                Medicament medicament = new Medicament();
                medicament.setidmedicament(id);

                medicament.setprixunitaireachatmedicament(prixunitaireachat);
                medicament.setprixventemedicament(prixvente);

                // Set other fields as needed

                try {
                    // Call the DAO method that may throw a SQLException
                    MedicamentDAO.updateMedicamentListeDesPrix(medicament);
                } catch (SQLException e) {
                    e.printStackTrace();
                    // Handle the exception locally if necessary
                }
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            // Handle appropriate exceptions
        } finally {
            IOUtils.closeQuietly(fileInputStream);
        }
    }
    }








