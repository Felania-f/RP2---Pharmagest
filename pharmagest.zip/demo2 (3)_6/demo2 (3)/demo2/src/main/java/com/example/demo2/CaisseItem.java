package com.example.demo2;
import javafx.beans.property.*;
public class CaisseItem {
    // Propriétés des items de caisse
    private final StringProperty idReceipt; // Identifiant du reçu
    private final StringProperty vendeur; // Nom du vendeur
    private final DoubleProperty total; // Total de la transaction

    // Constructeur de la classe
    public CaisseItem(String idReceipt,String vendeur, double total) {
        // Initialisation des propriétés avec les valeurs passées en paramètres
        this.idReceipt = new SimpleStringProperty(idReceipt);
        this.vendeur = new SimpleStringProperty(vendeur);
        this.total = new SimpleDoubleProperty(total);
    }
    // Getter and setter methods for idReceipt
    public String getIdReceipt() {
        return idReceipt.get();
    }
    public void setIdReceipt(String idReceipt) {
        this.idReceipt.set(idReceipt);
    }
    public StringProperty idReceiptProperty() {
        return idReceipt;
    }
    // Getter and setter methods for vendeur
    public String getvendeur() {
        return vendeur.get();
    }
    public void setvendeur(String vendeur) {
        this.vendeur.set(vendeur);
    }
    public StringProperty vendeurProperty() {
        return vendeur;
    }
    // Getter and setter methods for total
    public double getTotal() {
        return total.get();
    }
    public void setTotal(double total) {
        this.total.set(total);
    }
    public DoubleProperty totalProperty() {
        return total;
    }
}