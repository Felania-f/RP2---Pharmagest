package com.example.demo2;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class RécéptionController {
    // Reference to your TableView
    @FXML
    private TableView<Réception> receptionTable; // TableView pour afficher les reçus


    //TableColumn pour le montant total
    @FXML
    private TableColumn<Réception, Double> prixUnitaireReception;
    @FXML
    private TableColumn<Réception, Integer> idmedicamentColumn;
    @FXML
    private TableColumn<Réception, String> nomColumn;
    @FXML
    private TableColumn<Réception, String> fournisseurColumn;
    @FXML
    private TableColumn<Réception, Integer> quantiteColumn;
    @FXML
    private TableColumn<Réception, Double> totalColumn;
    @FXML
    private TextField searchTextField;
    @FXML
    private Label montanttotal;
    @FXML
    private TextField montantpayer;
    @FXML
    private TextField quantiteRecuReception;
    @FXML
    private Button mettreaJourButton;


    // Méthode d'initialisation appelée lorsque le contrôleur est initialisé
    @FXML
    public void initialize() {
        // Définit les usines de valeurs de cellules pour les colonnes de la table des reçus
        idmedicamentColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        nomColumn.setCellValueFactory(new PropertyValueFactory<>("nom"));
        fournisseurColumn.setCellValueFactory(new PropertyValueFactory<>("fournisseur"));
        prixUnitaireReception.setCellValueFactory(new PropertyValueFactory<>("prixunitaire"));
        quantiteColumn.setCellValueFactory(new PropertyValueFactory<>("quantite"));
        totalColumn.setCellValueFactory(new PropertyValueFactory<>("total"));

        // Call populateReceptionTable() during initialization
        populateReceptionTable();
        setupSearchListener();

        // Add a listener to the selection model of receptionTable
        receptionTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                // When a new item is selected, retrieve its idReceipt
                String selectedIdReceipt = String.valueOf(newSelection.getIdmedicament());
                // Populate RéceptionTable with related items based on selectedIdReceipt
                //populateRéceptionTable(selectedIdReceipt);
            }
        });

        // Add a listener to the TableView selection property
        receptionTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                // Get the total from the selected row
                double total = newSelection.getPrixunitaire() * newSelection.getQuantitecommande();

                // Update the montanttotal label with the total and euro symbol
                montanttotal.setText("Rs" + String.valueOf(total));

            }
        });
        mettreaJourButton.setOnAction(this::handleUpdateButtonAction);
    }

    @FXML
    private void handleUpdateButtonAction(ActionEvent event) {
        Réception selectedReceipt = receptionTable.getSelectionModel().getSelectedItem();
        if (selectedReceipt != null) {
            int quantiteRecu = Integer.parseInt(quantiteRecuReception.getText());
            updateQuantiteRecu(selectedReceipt.getIdmedicament(), quantiteRecu);
            populateReceptionTable(); // Rafraîchir la table
        } else {
            // Afficher un message d'erreur si aucune ligne n'est sélectionnée
            showAlert(AlertType.ERROR, "Erreur", "Aucune ligne sélectionnée", "Veuillez sélectionner une ligne dans la table.");
        }
    }

    private void updateQuantiteRecu(int idmedicament, int quantiteRecu) {
        try {
            // Récupérer la quantité commandée actuelle de la base de données
            String selectQuery = "SELECT quantitecommande FROM medicament WHERE id = ?";
            PreparedStatement selectStatement = DBUtil.dbConnect().prepareStatement(selectQuery);
            selectStatement.setInt(1, idmedicament);
            ResultSet resultSet = selectStatement.executeQuery();

            int quantiteCommande = 0;
            if (resultSet.next()) {
                quantiteCommande = resultSet.getInt("quantitecommande");
            }
            resultSet.close();
            selectStatement.close();

            if (quantiteRecu > quantiteCommande) {
                // Si quantiteRecu est supérieure à quantiteCommande, afficher une alerte et ne pas effectuer les mises à jour
                showAlert(AlertType.ERROR, "Erreur", "Quantité reçue supérieure à la commande", "La quantité reçue ne peut pas être supérieure à la quantité commandée.");
                return;
            } else if (quantiteRecu < quantiteCommande) {
                // Si quantiteRecu est inférieure à quantiteCommande, afficher une alerte et ne pas effectuer les mises à jour
                showAlert(AlertType.ERROR, "Erreur", "Quantité reçue inférieure à la commande", "La quantité reçue ne peut pas être inférieure à la quantité commandée.");
                return;
            }

            // Préparer la première requête de mise à jour (quantiterecu et quantiteenstock)
            String updateQuery1 = "UPDATE medicament SET quantiterecu = ?, quantiteenstock = quantiteenstock + ? WHERE id = ?";
            PreparedStatement updateStatement1 = DBUtil.dbConnect().prepareStatement(updateQuery1);
            updateStatement1.setInt(1, quantiteRecu);
            updateStatement1.setInt(2, quantiteRecu);
            updateStatement1.setInt(3, idmedicament);
            updateStatement1.executeUpdate();
            updateStatement1.close();

            // Préparer la deuxième requête de mise à jour (quantitecommande)
            String updateQuery2 = "UPDATE medicament SET quantitecommande = 0 WHERE id = ?";
            PreparedStatement updateStatement2 = DBUtil.dbConnect().prepareStatement(updateQuery2);
            updateStatement2.setInt(1, idmedicament);
            updateStatement2.executeUpdate();
            updateStatement2.close();

            // Afficher un message de confirmation
            showAlert(AlertType.INFORMATION, "Opération réussie", "Médicament reçu", "Le médicament a été reçu avec succès.");
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
    private void showAlert(AlertType type, String title, String header, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }

    // Configuration de la fonction de recherche pour filtrer les reçus
    private void setupSearchListener() {
        // Wrap the ObservableList of items in a FilteredList
        FilteredList<Réception> filteredList = new FilteredList<>(receptionTable.getItems(), p -> true);

        // Add a change listener to the text property of the searchTextField
        searchTextField.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredList.setPredicate(Réception -> {
                if (newValue == null || newValue.isEmpty()) {
                    // If the search text is empty, show all items
                    return true;
                }

                // Convert the search text to lowercase for case-insensitive search
                String searchText = newValue.toLowerCase();

                // Check if the receipt ID or total contains the search text
                return Réception.getNom().toLowerCase().contains(searchText);
            });
        });

        // Bind the filtered list to the TableView
        receptionTable.setItems(filteredList);
    }

    // Remplit la table des articles de reçu en fonction de l'identifiant de reçu sélectionné


    // Method to retrieve receipts with status "en cours" and populate the TableView
    public void populateReceptionTable() {
        try {
            // Fetch data from the database
            ResultSet resultSet = DBUtil.dbExecuteQuery("SELECT id, nom, fournisseur,quantitecommande,prixunitaireachat FROM medicament WHERE quantitecommande > 0");

            // Create ObservableList to hold the data
            ObservableList<Réception> réceptions = FXCollections.observableArrayList();

            // Populate the ObservableList with data from the ResultSet
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String nom = resultSet.getString("nom");
                String fournisseur = resultSet.getString("fournisseur");
                int quantitecommande = resultSet.getInt("quantitecommande");
                double prixunitaireachat = resultSet.getDouble("prixunitaireachat");


                Réception item = new Réception(id, nom, fournisseur,quantitecommande,prixunitaireachat);
                réceptions.add(item);
            }

            // Set the items to the TableView
            receptionTable.setItems(réceptions);
            // Set cell value factories to display data in the columns
            idmedicamentColumn.setCellValueFactory(cellData -> cellData.getValue().idmedicamentProperty().asObject());
            nomColumn.setCellValueFactory(cellData -> cellData.getValue().nomProperty());
            fournisseurColumn.setCellValueFactory(cellData -> cellData.getValue().fournisseurProperty());
            quantiteColumn.setCellValueFactory(cellData -> cellData.getValue().quantitecommandeProperty().asObject());
            totalColumn.setCellValueFactory(cellData ->cellData.getValue().totalProperty().asObject());
            // Close the ResultSet (and its Statement) after use
            resultSet.close();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace(); // Handle the exception as per your requirement
        }
    }

    @FXML
    private void envoyecommandebuttonclicked(ActionEvent event) {
    }

    private void updateQuantiteEnStock(int idMedicament, int quantiteRecue) {
        try {
            // Prepare the query to get the current quantity in stock
            String getQuantiteQuery = "SELECT quantiteenstock FROM medicament WHERE id = ?";
            PreparedStatement getQuantiteStatement = DBUtil.dbConnect().prepareStatement(getQuantiteQuery);
            getQuantiteStatement.setInt(1, idMedicament);

            // Execute the query and get the current quantity in stock
            ResultSet resultSet = getQuantiteStatement.executeQuery();
            int quantiteActuelle = 0;
            if (resultSet.next()) {
                quantiteActuelle = resultSet.getInt("quantiteenstock");
            }

            // Prepare the update statement to add the received quantity to the current quantity in stock
            int nouvelleQuantite = quantiteActuelle + quantiteRecue;
            String updateQuery = "UPDATE medicament SET quantiteenstock = ? WHERE id = ?";
            PreparedStatement updateStatement = DBUtil.dbConnect().prepareStatement(updateQuery);
            updateStatement.setInt(1, nouvelleQuantite);
            updateStatement.setInt(2, idMedicament);

            // Execute the update statement
            updateStatement.executeUpdate();

            // Close the statements
            getQuantiteStatement.close();
            updateStatement.close();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace(); // Handle the exception as per your requirement
        }
    }

    // Méthode pour gérer le processus de paiement
    @FXML
    public void handlePayerButtonAction(ActionEvent event) {
        // Calculate the amount to be returned (if applicable)
        double montantPayer = Double.parseDouble(montantpayer.getText()); // Assuming montantpayer is a TextField containing the amount paid
        double montantTotal = Double.parseDouble(montanttotal.getText().replace("Rs", "")); // Remove the euro symbol before parsing
        double montantRendre =montantPayer - montantTotal;

        // Check if the amount to be returned is greater than or equal to 0
        if (montantRendre >= 0) {
            // Retrieve the selected receipt ID
            Réception selectedRéception = receptionTable.getSelectionModel().getSelectedItem();
            String selectedIdReceipt = String.valueOf(selectedRéception.getIdmedicament());

                // Update the status of the selected receipt ID to "Payé" in the database
                updateReceiptStatus(selectedIdReceipt);
                String montantRendreFormatted = String.format("%.2f", montantRendre);
                // Create and configure the alert
                Alert alert = new Alert(AlertType.INFORMATION);
                alert.setTitle("Transaction réussie");
                alert.setHeaderText("La transaction a bien été effectuée");
                alert.setContentText("Montant à rendre: Rs" + montantRendreFormatted);

                // Show the alert
            alert.showAndWait().ifPresent(response -> {
                if (response == ButtonType.OK) {
                    // Clear the items in the RéceptionTable
                    receptionTable.getItems().clear();
                    // Refresh the page content
                    refreshPageContent();
                }
            });

        } else {
            // If the amount to be returned is negative, display an error
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText("Montant incorrect");
            alert.setContentText("Le montant à payer est inférieur au montant total.");

            // Show the alert
            alert.showAndWait();
        }
    }

    private void updateReceiptStatus(String idReceipt) {
        try {
            // Prepare the update statement to set the status to "Payé" for the given receipt ID
            String updateQuery = "UPDATE receipt SET status = 'Payé' WHERE receipt_id = ?;" +
                    "UPDATE receipt_items SET status = 'Payé' WHERE receipt_id = ?;";
            PreparedStatement updateStatement = DBUtil.dbConnect().prepareStatement(updateQuery);
            updateStatement.setString(1, idReceipt);
            updateStatement.setString(2, idReceipt);

            // Execute the update statement
            updateStatement.executeUpdate();

            // Close the statement
            updateStatement.close();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace(); // Handle the exception as per your requirement
        }
    }

    private void refreshPageContent() {
        // Here you can add the logic to refresh your page content.
        // For example, you can clear the text fields, reset the table views, etc.
        montantpayer.clear(); // Clear the text field for amount paid
        // You may need to repopulate the tables if needed
        populateReceptionTable(); // Example method call to repopulate the table
        // You can add additional refresh logic as per your requirements
    }
}
