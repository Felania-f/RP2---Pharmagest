package com.example.demo2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import static com.example.demo2.DashboardController.username;

public class MaintenanceController {
    // Initialisation des éléments de l'interface utilisateur
    private String userType = "User";
    private Stage primaryStage;

    @FXML
    private Button utilisateurButton;
    @FXML
    private Button FournisseurButton;
    @FXML
    private Button MedicamentButton;
    @FXML
    private Label usernameLabel;

    // Méthode pour définir le stage principal de l'application
    public void setPrimaryStage(Stage primaryStage) {
        this.primaryStage = primaryStage;
    }

    // Méthode pour récupérer le type d'utilisateur à partir de la base de données
    private String getUserTypeFromDatabase(String username) {
        // Connexion à la base de données
        try (Connection connectDB = DatabaseConnection.getConnection("Pharmagest", "postgres", "voahary")) {
            String userTypeQuery = "SELECT permission FROM useraccounts WHERE username = ?";
            try (PreparedStatement preparedStatement = connectDB.prepareStatement(userTypeQuery)) {
                preparedStatement.setString(1, username);

                // Exécution de la requête et récupération du résultat
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        return resultSet.getString("permission");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "User";
    }

    // Méthode d'initialisation du contrôleur
    public void initialize(String username) {
        System.out.println("Username: " + username);
        // Récupération du type d'utilisateur depuis la base de données
        String userTypeFromDB = getUserTypeFromDatabase(username);
        System.out.println("User type from DB: " + userTypeFromDB);
        setUserType(userTypeFromDB);
        // Affichage du nom d'utilisateur dans l'interface
        usernameLabel.setText("Username: " + username);

        // Définition des actions des boutons
        FournisseurButton.setOnAction(event -> openFournisseurMaintenanceScene());
        MedicamentButton.setOnAction(event -> openMedicamentMaintenanceScene());
    }

    // Méthode pour définir le type d'utilisateur et mettre à jour l'interface
    public void setUserType(String userType) {
        this.userType = userType;
        updateUI();
    }

    // Méthode pour mettre à jour l'interface en fonction du type d'utilisateur
    private void updateUI() {
        System.out.println("Type d'utilisateur : " + userType);

        if ("SU".equals(userType)) {
            System.out.println("Afficher le bouton utilisateur.");
            utilisateurButton.setVisible(true);
            utilisateurButton.setOnAction(event -> openUtilisateurMaintenanceScene());
        } else {
            System.out.println("Masquer le bouton utilisateur.");
            utilisateurButton.setVisible(false);
        }
    }

    // Méthode pour ouvrir une nouvelle fenetre de maintenance pour l'utilisateur
    private void openUtilisateurMaintenanceScene() {
        try {
            UtilisateurMaintenance utilisateurMaintenance = new UtilisateurMaintenance();
            utilisateurMaintenance.start(new Stage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Méthode pour ouvrir une nouvelle fenetre de maintenance pour le fournisseur
    private void openFournisseurMaintenanceScene() {
        try {
            FournisseurMaintenance fournisseurMaintenance = new FournisseurMaintenance();
            fournisseurMaintenance.start(new Stage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Méthode pour ouvrir la scène de maintenance pour le médicament
    private void openMedicamentMaintenanceScene() {
        try {
            MedicamentMaintenance medicamentMaintenance = new MedicamentMaintenance();
            medicamentMaintenance.start(new Stage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Méthode pour gérer le clic sur le bouton "Retour"
    @FXML
    private void handleRetourButton(ActionEvent event) {
        try {
            // Fermeture de la scène de maintenance actuelle
            Stage maintenanceStage = (Stage) usernameLabel.getScene().getWindow();
            maintenanceStage.close();

            // Chargement de la scène du tableau de bord
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Dashboard.fxml"));
            Parent root = loader.load();

            Scene scene = new Scene(root, 1900, 558);
            Stage dashboardStage = new Stage();
            dashboardStage.setScene(scene);
            dashboardStage.setTitle("Dashboard");
            dashboardStage.setMaximized(true);
            dashboardStage.show();

            // Passer le nom d'utilisateur à la scène du tableau de bord
            DashboardController controller = loader.getController();
            controller.setPrimaryStage(dashboardStage);
            controller.setUsername(username); // Pass the username
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Error loading Dashboard.fxml: " + e.getMessage());
        }
    }
}
