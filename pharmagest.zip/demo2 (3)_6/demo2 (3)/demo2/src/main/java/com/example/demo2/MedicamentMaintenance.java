package com.example.demo2;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import java.io.IOException;

//Ce code Java définit une application JavaFX avec une classe MedicamentMaintenance qui initialise une mise en page
// principale (RootLayout) et affiche la vue des opérations sur les employés (EmployeeOperationsView). La mise en page
// est chargée à partir des fichiers FXML correspondants, et la vue des opérations sur les employés est affichée au
// centre de la mise en page.

//Main class which extends from Application Class
public class MedicamentMaintenance extends Application {

    //C'est notre PrimaryStage (Il contient tout)
    private Stage primaryStage;

    //C'est le BorderPane de RootLayout
    private BorderPane rootLayout;

    @Override
    public void start(Stage primaryStage) {
        //Déclare un primary stage (Tout sera sur ce stage)
        this.primaryStage = primaryStage;

        //Optionnel : Définir un titre pour le primary stage
        this.primaryStage.setTitle("SW Test Academy - Sample JavaFX App");

        //2) Initialiser RootLayout
        initRootLayout();

        //3) Afficher la vue EmployeeOperations
        showEmployeeView();
    }

    //Initialise la mise en page racine.
    public void initRootLayout() {
        try {
            //First, load root layout from RootLayout.fxml
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MedicamentMaintenance.class.getResource("RootLayout.fxml"));
            rootLayout = (BorderPane) loader.load();

            // Définir la largeur et la hauteur désirées pour la mise en page
            rootLayout.setPrefWidth(1435);
            rootLayout.setPrefHeight(790);

            //Ensuite, affiche la scène contenant la mise en page .
            Scene scene = new Scene(rootLayout, 1435, 762); //We are sending rootLayout to the Scene.
            primaryStage.setScene(scene); //Set the scene in primary stage.

        /*//Give the controller access to the main.
        RootLayoutController controller = loader.getController();
        controller.setMain(this);*/

            //Troisièmement, affiche le primary stage
            primaryStage.show(); //Affiche le primary stage
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //Affiche la vue des opérations sur les employés à l'intérieur de la mise en page
    public void showEmployeeView() {
        try {
            //D'abord, charge EmployeeView depuis EmployeeView.fxml
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MedicamentMaintenance.class.getResource("MedicamentMaintenance.fxml"));
            AnchorPane employeeOperationsView = (AnchorPane) loader.load();

            // Définit la vue des opérations sur les employés au centre de la mise en page .
            rootLayout.setCenter(employeeOperationsView);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
