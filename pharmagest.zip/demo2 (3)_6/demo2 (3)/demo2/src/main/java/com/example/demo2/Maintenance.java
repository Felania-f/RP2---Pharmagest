package com.example.demo2;

import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class Maintenance extends Application {

    public static void main(String[] args) {
        // Lance l'application JavaFX
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        try {
            // Charge le fichier FXML de l'interface utilisateur de maintenance
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Maintenance.fxml"));
            Parent root = loader.load();

            // Accède au MaintenanceController
            MaintenanceController controller = loader.getController();

            //Récupère le nom d'utilisateur de la classe DashboardController
            String username = DashboardController.username;
            // Initialise le contrôleur avec le nom d'utilisateur
            controller.initialize(username);

            // Crée une scène avec l'interface utilisateur chargée
            Scene scene = new Scene(root);

            // Définit la scène sur la fenêtre principale
            primaryStage.setScene(scene);

            // Définit le titre de la fenêtre
            primaryStage.setTitle("Maintenance App");
            //Maximise la fenêtre
            primaryStage.setMaximized(true);

            // Affiche la fenêtre
            primaryStage.show();
        } catch (Exception e) {
            // En cas d'erreur, affiche la trace de la pile
            e.printStackTrace();
        }
    }
}
