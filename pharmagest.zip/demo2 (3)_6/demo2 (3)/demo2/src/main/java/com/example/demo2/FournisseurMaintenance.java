package com.example.demo2;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import java.io.IOException;

//Main class which extends from Application Class
public class FournisseurMaintenance extends Application {

    // C'est notre PrimaryStage (Il contient tout)
    private Stage primaryStage;

    // C'est le BorderPane de RootLayout
    private BorderPane rootLayout;

    @Override
    public void start(Stage primaryStage) {
        // 1) Déclare un primary stage (Tout sera sur ce stage)
        this.primaryStage = primaryStage;

        // Optionnel : Définit un titre pour le primary stage
        this.primaryStage.setTitle("SW Test Academy - Sample JavaFX App");

        // 2) Initialise RootLayout
        initRootLayout();

        // 3) Affiche la vue EmployeeOperations
        showEmployeeView();
    }

    //Initializes the root layout.
    public void initRootLayout() {
        try {
            //First, charge root layout from RootLayout.fxml
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(FournisseurMaintenance.class.getResource("RootLayout.fxml"));
            rootLayout = (BorderPane) loader.load();

            //Second, show the scene containing the root layout.
            Scene scene = new Scene(rootLayout); //We are sending rootLayout to the Scene.
            primaryStage.setScene(scene); //Set the scene in primary stage.

            /*//Give the controller access to the main.
            RootLayoutController controller = loader.getController();
            controller.setMain(this);*/

            //Third, show the primary stage
            primaryStage.show(); //Display the primary stage
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Affiche la vue des opérations sur les employés à l'intérieur de la mise en page racine.
    public void showEmployeeView() {
        try {
            // Tout d'abord, charge EmployeeView depuis EmployeeView.fxml
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(FournisseurMaintenance.class.getResource("FournisseurMaintenance.fxml"));
            AnchorPane employeeOperationsView = (AnchorPane) loader.load();

            // Set Employee Operations view into the center of root layout.
            rootLayout.setCenter(employeeOperationsView);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
