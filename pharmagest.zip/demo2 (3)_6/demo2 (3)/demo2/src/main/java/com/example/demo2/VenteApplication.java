// Package contenant la classe principale de l'application
package com.example.demo2;

// Import des classes JavaFX nécessaires
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import java.io.IOException;

// Classe principale de l'application, héritant de la classe Application de JavaFX
public class VenteApplication extends Application {

    // Stage principal de l'application (contient tout)
    private Stage primaryStage;

    // BorderPane du RootLayout
    private BorderPane rootLayout;

    @Override
    // Méthode principale de l'application JavaFX, appelée au lancement de l'application
    public void start(Stage primaryStage) {
        // 1) Déclaration du stage principal (Tout sera affiché sur ce stage)
        this.primaryStage = primaryStage;

        // Optionnel: Définition d'un titre pour le stage principal
        this.primaryStage.setTitle("SW Test Academy - Sample JavaFX App");

        // 2) Initialisation du RootLayout
        initRootLayout();

        // 3) Affichage de la vue des opérations liées aux employés
        showEmployeeView();
    }

    // Initialise le layout principal
    public void initRootLayout() {
        try {
            // Chargement du layout principal depuis RootLayout.fxml
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MedicamentMaintenance.class.getResource("RootLayout.fxml"));
            rootLayout = (BorderPane) loader.load();

            // Définition de la largeur et de la hauteur souhaitées pour le layout principal
            rootLayout.setPrefWidth(1435);
            rootLayout.setPrefHeight(800);

            // Affichage de la scène contenant le layout principal
            Scene scene = new Scene(rootLayout, 1435, 800); // Le layout principal est envoyé à la scène.
            primaryStage.setScene(scene); // Définition de la scène dans le stage principal.

            // Affichage du stage principal
            primaryStage.show(); // Affichage du stage principal
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Affiche la vue des opérations liées aux employés à l'intérieur du layout principal
    public void showEmployeeView() {
        try {
            // Chargement de la vue des opérations liées aux employés depuis EmployeeView.fxml
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MedicamentMaintenance.class.getResource("Vente.fxml"));
            AnchorPane employeeOperationsView = (AnchorPane) loader.load();

            // Affichage de la vue des opérations liées aux employés au centre du layout principal
            rootLayout.setCenter(employeeOperationsView);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}